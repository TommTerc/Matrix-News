const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = 8080;

app.use(cors());

// Proxy endpoint for News API
app.get('/api/news/*', async (req, res) => {
  try {
    const apiKey = process.env.VITE_NEWS_API_KEY;
    const path = req.params[0];
    const queryString = new URLSearchParams(req.query).toString();
    
    const response = await axios.get(
      `https://newsapi.org/v2/${path}?${queryString}`,
      {
        headers: {
          'X-Api-Key': apiKey
        }
      }
    );
    
    res.json(response.data);
  } catch (error) {
    console.error('Proxy error:', error);
    res.status(error.response?.status || 500).json({
      status: 'error',
      message: error.message
    });
  }
});

app.listen(PORT, () => {
  console.log(`Proxy server running on port ${PORT}`);
});