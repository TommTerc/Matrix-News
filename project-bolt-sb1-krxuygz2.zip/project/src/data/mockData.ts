// News item interfaces
export interface NewsItem {
  id: string;
  title: string;
  description: string;
  source: string;
  timestamp: Date;
  image: string;
  likes: number;
  comments: number;
  shares: number;
  views: number;
  trending: boolean;
  keywords: string[];
}

// Comment interface for Reddit-style comments
export interface Comment {
  id: string;
  content: string;
  author: string;
  timestamp: Date;
  upvotes: number;
  downvotes: number;
  replies: Comment[];
}

// Timeline event interface
export interface TimelineEvent {
  id: string;
  title: string;
  description: string;
  timestamp: Date;
  type: 'update' | 'announcement' | 'development';
  image: string;
  source: string;
  comments: Comment[];
}

// Mock news data
export const mockNews: NewsItem[] = [
  {
    id: '1',
    title: 'BREAKING: Major Tech Announcement Shakes Silicon Valley',
    description: 'Revolutionary AI breakthrough promises to transform the technology landscape as we know it. Industry leaders gather to discuss implications.',
    source: 'Tech Daily',
    timestamp: new Date(),
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&auto=format&fit=crop',
    likes: 1234,
    comments: 456,
    shares: 789,
    views: 50000,
    trending: true,
    keywords: ['AI', 'technology', 'Silicon Valley', 'innovation']
  },
  {
    id: '2',
    title: 'WORLD LEADERS GATHER: Climate Summit Begins',
    description: 'Global leaders converge for unprecedented climate action summit. New agreements expected to reshape environmental policies.',
    source: 'World News',
    timestamp: new Date(Date.now() - 3600000),
    image: 'https://images.unsplash.com/photo-1470723710355-95304d8aece4?w=800&auto=format&fit=crop',
    likes: 2345,
    comments: 567,
    shares: 890,
    views: 45000,
    trending: true,
    keywords: ['climate change', 'environment', 'global summit', 'policy']
  },
  {
    id: '3',
    title: 'CYBERSECURITY ALERT: Major Platform Breach Detected',
    description: 'Security experts scramble to contain widespread system vulnerability. Users advised to update credentials immediately.',
    source: 'Cyber Security Today',
    timestamp: new Date(Date.now() - 7200000),
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop',
    likes: 3456,
    comments: 789,
    shares: 1234,
    views: 60000,
    trending: true,
    keywords: ['cybersecurity', 'data breach', 'security', 'technology']
  }
];

// Timeline events data
export const timelineEvents: Record<string, TimelineEvent[]> = {
  '1': [
    {
      id: 't1',
      title: 'OpenAI Announces GPT-5',
      description: 'Tech breakthrough first revealed to the public',
      timestamp: new Date(2024, 0, 15, 9, 0),
      type: 'announcement',
      image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&auto=format&fit=crop',
      source: 'Tech Daily',
      comments: [
        {
          id: 'c1',
          content: 'This is a game-changer for the AI industry!',
          author: 'TechEnthusiast',
          timestamp: new Date(2024, 0, 15, 9, 30),
          upvotes: 245,
          downvotes: 12,
          replies: [
            {
              id: 'c1r1',
              content: 'Absolutely agree. The implications for natural language processing are huge.',
              author: 'AIResearcher',
              timestamp: new Date(2024, 0, 15, 9, 45),
              upvotes: 123,
              downvotes: 5,
              replies: []
            }
          ]
        },
        {
          id: 'c2',
          content: 'What about the ethical implications?',
          author: 'EthicsFirst',
          timestamp: new Date(2024, 0, 15, 10, 0),
          upvotes: 189,
          downvotes: 8,
          replies: []
        }
      ]
    },
    {
      id: 't2',
      title: 'GPT-5 Technical Deep Dive',
      description: 'Detailed specifications and implementation plans shared',
      timestamp: new Date(2024, 0, 15, 14, 30),
      type: 'development',
      image: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&auto=format&fit=crop',
      source: 'AI Weekly',
      comments: []
    },
    {
      id: 't3',
      title: 'Tech Giants React to GPT-5',
      description: 'Major tech companies announce adoption plans',
      timestamp: new Date(2024, 0, 16, 10, 0),
      type: 'update',
      image: 'https://images.unsplash.com/photo-1661956602116-aa6865609028?w=800&auto=format&fit=crop',
      source: 'Silicon Valley News',
      comments: []
    },
    {
      id: 't4',
      title: 'GPT-5 Market Impact',
      description: 'Stock markets react to the announcement',
      timestamp: new Date(2024, 0, 16, 16, 0),
      type: 'update',
      image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&auto=format&fit=crop',
      source: 'Financial Times',
      comments: []
    }
  ],
  '2': [
    {
      id: 't5',
      title: 'Climate Summit Begins',
      description: 'World leaders gather for opening ceremony',
      timestamp: new Date(2024, 1, 1, 9, 0),
      type: 'announcement',
      image: 'https://images.unsplash.com/photo-1470723710355-95304d8aece4?w=800&auto=format&fit=crop',
      source: 'Global News',
      comments: []
    },
    {
      id: 't6',
      title: 'Climate Action Proposals',
      description: 'Major climate action proposals presented',
      timestamp: new Date(2024, 1, 1, 14, 0),
      type: 'development',
      image: 'https://images.unsplash.com/photo-1421789665209-c9b2a435e3dc?w=800&auto=format&fit=crop',
      source: 'Environmental Report',
      comments: []
    }
  ],
  '3': [
    {
      id: 't7',
      title: 'Security Breach Alert',
      description: 'Security teams identify major vulnerability',
      timestamp: new Date(2024, 1, 10, 8, 0),
      type: 'announcement',
      image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&auto=format&fit=crop',
      source: 'Cyber Defense Weekly',
      comments: []
    },
    {
      id: 't8',
      title: 'Emergency Patches Deployed',
      description: 'Security patches deployed across affected systems',
      timestamp: new Date(2024, 1, 10, 10, 30),
      type: 'development',
      image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&auto=format&fit=crop',
      source: 'Tech Security Now',
      comments: []
    },
    {
      id: 't9',
      title: 'Security Advisory',
      description: 'Public notification and security recommendations issued',
      timestamp: new Date(2024, 1, 10, 12, 0),
      type: 'update',
      image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop',
      source: 'Cybersecurity Times',
      comments: []
    }
  ]
};