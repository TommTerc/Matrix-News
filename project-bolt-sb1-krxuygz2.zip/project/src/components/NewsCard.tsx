import React from 'react';
import { Link } from 'react-router-dom';
import { FaEye, FaRegClock } from 'react-icons/fa';
import { formatDistanceToNow } from 'date-fns';
import { NewsApiArticle } from '../services/newsApi';

interface NewsCardProps {
  article: NewsApiArticle;
}

export default function NewsCard({ article }: NewsCardProps) {
  return (
    <article className="border border-matrix-green/30 rounded-lg overflow-hidden hover:border-matrix-green transition-all group bg-gradient-to-b from-gray-900/80 via-gray-800/85 to-gray-900/80 hover:shadow-lg hover:shadow-matrix-green/20">
      <a href={article.url} target="_blank" rel="noopener noreferrer">
        {article.urlToImage && (
          <img 
            src={article.urlToImage} 
            alt={article.title}
            className="w-full h-48 object-cover transition-transform group-hover:scale-105"
          />
        )}
        <div className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-matrix-green/60 text-sm flex items-center gap-1">
              <FaRegClock /> {formatDistanceToNow(new Date(article.publishedAt))} ago
            </span>
          </div>
          <h2 className="text-xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-matrix-green via-matrix-light to-matrix-green group-hover:from-matrix-light group-hover:via-matrix-green group-hover:to-matrix-light transition-all">
            {article.title}
          </h2>
          <p className="text-matrix-green/80 mb-4">{article.description}</p>
          <div className="flex justify-between items-center text-matrix-green/60 text-sm">
            <span>{article.source.name}</span>
            {article.author && <span>By {article.author}</span>}
          </div>
        </div>
      </a>
    </article>
  );
}