import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { FaHome, FaHashtag, FaBell, FaBookmark, FaUser, FaSearch, FaChartLine, FaEye, FaBolt, FaGlobe, FaCog, FaSignOutAlt } from 'react-icons/fa';
import { formatDistanceToNow } from 'date-fns';
import { mockNews } from './data/mockData';
import NewsDetail from './pages/NewsDetail';
import Studio from './pages/Studio';
import Explore from './pages/Explore';
import Auth from './pages/Auth';
import Terms from './pages/Terms';
import Privacy from './pages/Privacy';
import MatrixRain from './components/MatrixRain';
import Notifications from './pages/Notifications';
import Profile from './pages/Profile';
import Home from './pages/Home';

function SidebarLink({ to, icon: Icon, label, isActive }: { to: string; icon: React.ComponentType; label: string; isActive: boolean }) {
  return (
    <Link 
      to={to}
      className={`flex items-center gap-4 px-4 py-3 rounded-lg transition-colors ${
        isActive 
          ? 'bg-matrix-green/20 text-matrix-light' 
          : 'hover:bg-matrix-green/10 text-matrix-green hover:text-matrix-light'
      }`}
    >
      <Icon className="text-xl" />
      <span className="text-lg">{label}</span>
    </Link>
  );
}

function Sidebar() {
  const location = useLocation();
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <div className="h-full bg-matrix-black/95 backdrop-blur-sm border-r border-matrix-green/30 flex flex-col py-4">
      {/* Logo */}
      <Link to="/" className="px-4 py-2 mb-8">
        <h1 className="text-2xl font-bold text-matrix-green">NEWS MATRIX</h1>
      </Link>

      {/* Main Navigation */}
      <nav className="flex-1 px-2 space-y-1">
        <SidebarLink 
          to="/" 
          icon={FaHome} 
          label="Home" 
          isActive={location.pathname === '/'} 
        />
        <SidebarLink 
          to="/explore" 
          icon={FaHashtag} 
          label="Explore" 
          isActive={location.pathname === '/explore'} 
        />
        <SidebarLink 
          to="/notifications" 
          icon={FaBell} 
          label="Notifications" 
          isActive={location.pathname === '/notifications'} 
        />
        <SidebarLink 
          to="/bookmarks" 
          icon={FaBookmark} 
          label="Bookmarks" 
          isActive={location.pathname === '/bookmarks'} 
        />
        <SidebarLink 
          to="/profile" 
          icon={FaUser} 
          label="Profile" 
          isActive={location.pathname === '/profile'} 
        />
      </nav>

      {/* User Menu */}
      <div className="px-2 mt-auto relative">
        <button
          onClick={() => setShowUserMenu(!showUserMenu)}
          className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-matrix-green/10 transition-colors text-matrix-green hover:text-matrix-light"
        >
          <div className="w-10 h-10 rounded-full bg-matrix-green/20 flex items-center justify-center">
            <FaUser />
          </div>
          <div className="flex-1 text-left">
            <div className="font-bold">Username</div>
            <div className="text-sm text-matrix-green/60">@handle</div>
          </div>
        </button>

        {/* Dropdown Menu */}
        {showUserMenu && (
          <div className="absolute bottom-full left-2 right-2 mb-2 bg-matrix-black border border-matrix-green/30 rounded-lg shadow-lg overflow-hidden">
            <Link
              to="/settings"
              className="flex items-center gap-3 px-4 py-3 hover:bg-matrix-green/10 text-matrix-green hover:text-matrix-light"
            >
              <FaCog />
              <span>Settings</span>
            </Link>
            <button
              onClick={() => {/* Handle logout */}}
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-matrix-green/10 text-matrix-green hover:text-matrix-light"
            >
              <FaSignOutAlt />
              <span>Sign Out</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function SearchBar() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="fixed top-0 left-64 right-0 bg-matrix-black/95 backdrop-blur-sm border-b border-matrix-green/30 px-4 py-3 z-50">
      <div className="max-w-3xl mx-auto relative">
        <div className="relative flex items-center">
          <FaSearch className="absolute left-4 text-matrix-green/60" />
          <input
            type="search"
            placeholder="Search Matrix"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-matrix-dark border border-matrix-green/30 rounded-full pl-12 pr-4 py-2.5 text-matrix-green focus:outline-none focus:border-matrix-green transition-all hover:border-matrix-green/60 placeholder-matrix-green/40"
          />
        </div>
        
        {/* Optional: Add a subtle glow effect */}
        <div className="absolute inset-0 rounded-full bg-matrix-green/5 filter blur-xl pointer-events-none"></div>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <div className="relative min-h-screen flex">
        {/* Dark overlay for better contrast */}
        <div className="absolute inset-0 bg-black/95 backdrop-blur-sm" />
        
        {/* Matrix rain effect */}
        <MatrixRain />
        
        {/* Radial gradient for depth */}
        <div className="absolute inset-0 bg-gradient-radial from-transparent via-black/50 to-black pointer-events-none" />
        
        {/* Content */}
        <div className="relative z-10 flex-1 ml-64">
          {/* Search Bar with flow animation */}
          <div className="flow-in">
            <SearchBar />
          </div>

          {/* Content Area */}
          <div className="relative z-10 pt-16">
            <div className="flow-scale">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/news/:id" element={<NewsDetail />} />
                <Route path="/studio" element={<Studio />} />
                <Route path="/explore" element={<Explore />} />
                <Route path="/notifications" element={<Notifications />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/auth" element={<Auth />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="/privacy" element={<Privacy />} />
              </Routes>
            </div>
          </div>
        </div>

        {/* Sidebar with flow animation */}
        <div className="flow-left fixed top-0 left-0 h-screen w-64">
          <Sidebar />
        </div>
      </div>
    </Router>
  );
}

export default App;