import React, { useState } from 'react';
import { FaChartLine, FaBolt, FaHashtag, FaGlobe } from 'react-icons/fa';
import { useNews } from '../hooks/useNews';
import NewsCard from '../components/NewsCard';

export default function Home() {
  const [category, setCategory] = useState<string | undefined>();
  
  const { articles = [], loading, error } = useNews({
    category,
    pageSize: 12
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-matrix-black/40 backdrop-blur-[2px] font-mono">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-48 bg-matrix-green/20 rounded-lg mb-4"></div>
                <div className="h-4 bg-matrix-green/20 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-matrix-green/20 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-matrix-black/40 backdrop-blur-[2px] font-mono flex items-center justify-center">
        <div className="text-matrix-green text-center">
          <h2 className="text-2xl font-bold mb-2">Error Loading News</h2>
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-matrix-black/40 backdrop-blur-[2px] font-mono">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Category Tabs */}
        <div className="flex gap-4 mb-8 overflow-x-auto pb-2">
          {['general', 'technology', 'business', 'science', 'health', 'sports', 'entertainment'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat === 'general' ? undefined : cat)}
              className={`px-4 py-2 rounded-full border transition-colors whitespace-nowrap ${
                (category === cat || (!category && cat === 'general'))
                  ? 'bg-matrix-green text-matrix-black border-matrix-green'
                  : 'border-matrix-green/30 text-matrix-green hover:border-matrix-green'
              }`}
            >
              {cat.charAt(0).toUpperCase() + cat.slice(1)}
            </button>
          ))}
        </div>

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article) => (
            <NewsCard key={article.url} article={article} />
          ))}
        </div>
      </div>
    </div>
  );
}