import { useState, useEffect } from 'react';
import newsApi, { NewsApiArticle } from '../services/newsApi';

interface UseNewsParams {
  country?: string;
  category?: string;
  query?: string;
  pageSize?: number;
  page?: number;
}

export function useNews({
  country = 'us',
  category,
  query,
  pageSize = 10,
  page = 1,
}: UseNewsParams = {}) {
  const [articles, setArticles] = useState<NewsApiArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalResults, setTotalResults] = useState(0);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        setLoading(true);
        const response = await newsApi.getTopHeadlines({
          country,
          category,
          q: query,
          pageSize,
          page,
        });
        setArticles(response.articles);
        setTotalResults(response.totalResults);
        setError(null);
      } catch (err) {
        setError('Failed to fetch news');
        console.error('Error fetching news:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
  }, [country, category, query, pageSize, page]);

  return { articles, loading, error, totalResults };
}