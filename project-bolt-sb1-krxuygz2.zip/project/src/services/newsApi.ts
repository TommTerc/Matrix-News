import axios from 'axios';
import { API_CONFIG } from '../config/api.config';

export interface NewsApiArticle {
  source: {
    id: string | null;
    name: string;
  };
  author: string | null;
  title: string;
  description: string | null;
  url: string;
  urlToImage: string | null;
  publishedAt: string;
  content: string | null;
}

export interface NewsApiResponse {
  status: string;
  totalResults: number;
  articles: NewsApiArticle[];
}

const newsApi = {
  getTopHeadlines: async (params?: {
    country?: string;
    category?: string;
    q?: string;
    pageSize?: number;
    page?: number;
  }): Promise<NewsApiResponse> => {
    try {
      const response = await axios.get(`https://newsapi.org/v2/top-headlines`, {
        params: {
          ...params,
          apiKey: API_CONFIG.newsApi.apiKey,
        },
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching top headlines:', error);
      throw error;
    }
  },

  getEverything: async (params: {
    q?: string;
    from?: string;
    to?: string;
    language?: string;
    sortBy?: 'relevancy' | 'popularity' | 'publishedAt';
    pageSize?: number;
    page?: number;
  }): Promise<NewsApiResponse> => {
    try {
      const response = await axios.get(`https://newsapi.org/v2/everything`, {
        params: {
          ...params,
          apiKey: API_CONFIG.newsApi.apiKey,
        },
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching articles:', error);
      throw error;
    }
  },

  getSources: async (params?: {
    category?: string;
    language?: string;
    country?: string;
  }) => {
    try {
      const response = await axios.get(`https://newsapi.org/v2/sources`, {
        params: {
          ...params,
          apiKey: API_CONFIG.newsApi.apiKey,
        },
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching sources:', error);
      throw error;
    }
  },
};

export default newsApi;